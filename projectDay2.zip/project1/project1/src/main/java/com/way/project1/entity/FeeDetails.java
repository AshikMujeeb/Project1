package com.way.project1.entity;

import java.util.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FeeDetails {
	@Id
	@GeneratedValue
	private long id;
	private String coursename;
	private String username;
	private int feesPaid;
	private Date feesPaidDate;
	private int balanceFees;
}
