package com.way.project1.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user_details")
public class User {
	@Id
	@GeneratedValue
	private long id;
	private String first_name;
	private String last_name;
	private String email;
	private long ph_no;
	private Date dob;
	private String userName;
	private String password;
}
