package com.way.project1.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.way.project1.dto.CourseDeletionConfirmation;
import com.way.project1.dto.CourseDetailsEnteringRequest;
import com.way.project1.dto.CourseDetailsEnteringResponse;
import com.way.project1.dto.DetailsEnteringConfirmation;
import com.way.project1.dto.DetailsEnteringRequest;
import com.way.project1.entity.Academic;
import com.way.project1.entity.Course;
import com.way.project1.entity.User;

public interface StudentAcademicService extends UserDetailsService{
	public DetailsEnteringConfirmation EnterDetails(DetailsEnteringRequest detailsEnteringRequest );
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException;
	public User getStudentByUseName(String username);
	public Academic getAcademicDetailsByUseName(String username);
	
	public User updateStudentDetails(String username,User user);
	public Academic updateStudentAcademicDetails(String username);
	public CourseDetailsEnteringResponse courseEnteringDetails(CourseDetailsEnteringRequest courseDetailsEnteringRequest);
	public Course updateCourseDetails(String courseName, Course course);
	public CourseDeletionConfirmation courseDetailsDeletion(String userName);
	public Course getCourseByCourseName(String courseName);
	public List<Course>  getAllCourse();
}
