package com.way.project1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.way.project1.entity.Course;

public interface CourseRepository extends JpaRepository<Course, Long>{

	public Course findByCourseName(String courseName);

	
	
}
