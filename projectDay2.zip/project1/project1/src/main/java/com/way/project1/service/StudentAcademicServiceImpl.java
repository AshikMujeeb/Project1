package com.way.project1.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.way.project1.dto.CourseDeletionConfirmation;
import com.way.project1.dto.CourseDetailsEnteringRequest;
import com.way.project1.dto.CourseDetailsEnteringResponse;
import com.way.project1.dto.DetailsEnteringConfirmation;
import com.way.project1.dto.DetailsEnteringRequest;
import com.way.project1.entity.Academic;
import com.way.project1.entity.Course;
import com.way.project1.entity.User;
import com.way.project1.repository.AcademicRepository;
import com.way.project1.repository.CourseRepository;
import com.way.project1.repository.UserRepository;


@Service
public class StudentAcademicServiceImpl implements StudentAcademicService{
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private AcademicRepository academicRepository;
	@Autowired
	private CourseRepository courseRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByUserName(username);
		return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), new ArrayList<>());
	}
	@Override
	public DetailsEnteringConfirmation EnterDetails(DetailsEnteringRequest detailsEnteringRequest ) {
		User user = detailsEnteringRequest.getUser();
		userRepository.save(user);
		Academic academic = detailsEnteringRequest.getAcademic();
		academic.setId(user.getId());
		academicRepository.save(academic);
		return new DetailsEnteringConfirmation(user.getFirst_name(),"Student successfully added!");
	}
	@Override
	public User getStudentByUseName(String username) {
		Optional<User> optional = Optional.ofNullable(userRepository.findByUserName(username));
		if(optional.isEmpty() )
			return null;
		else
			return optional.get();
	}
	@Override
	public User updateStudentDetails(String username, User user) {
		Optional<User> optional = Optional.ofNullable(userRepository.findByUserName(username));
		User user1 = null;
		if(optional.isEmpty()) {
			return null;
		}else {
			user1 = optional.get();
			user1.setEmail(user.getEmail());
			user1.setPh_no(user.getPh_no());
			user1.setPassword(user.getPassword());
			return user1;
		}
	}
	@Override
	public Course updateCourseDetails(String courseName, Course course) {
		Optional<Course> optional = Optional.ofNullable(courseRepository.findByCourseName(courseName));
		Course course1 = null;
		if(optional.isEmpty()) {
			return null;
		}else {
			course1 = optional.get();
			course1.setCourseName(course.getCourseName());
			course1.setDescription(course.getDescription());
			course1.setFees(course.getFees());
			return course1;
		}
	}
	@Override
	public Academic updateStudentAcademicDetails(String username) {
		Optional<User> optional = Optional.ofNullable(userRepository.findByUserName(username));
		User user = null;
		Long id = null;
		Academic academic = null;
		if(optional.isPresent()) {
			user = optional.get();
			id = user.getId();
			Optional<Academic> opt = academicRepository.findById(id);
			if(opt.isPresent()) {
				academic = opt.get();
				return academic;
			}
		}
		return null;
	}
	@Override
	public CourseDetailsEnteringResponse courseEnteringDetails(
			CourseDetailsEnteringRequest courseDetailsEnteringRequest) {
		Course course = courseDetailsEnteringRequest.getCourse();
		courseRepository.save(course);
		return new CourseDetailsEnteringResponse(course.getCourseName(),"Successful");
	}
	@Override
	public CourseDeletionConfirmation courseDetailsDeletion(String courseName) {
		Optional<Course> optional =  Optional.ofNullable(courseRepository.findByCourseName(courseName));
		Course course = null;
		if(optional.isPresent()) {
			course = optional.get();	
		}
		courseRepository.delete(course);
		return new CourseDeletionConfirmation("Deletion Successful!");
	}
	@Override
	public Course getCourseByCourseName(String courseName) {
		Optional<Course> optional = Optional.ofNullable(courseRepository.findByCourseName(courseName));
		Course c1 = null;
		if(optional.isPresent()) {
			c1 = optional.get();
			return c1;
		}
		else {
			return null;
		}
	}
	@Override
	public Academic getAcademicDetailsByUseName(String username) {
		Optional<User> optional = Optional.ofNullable(userRepository.findByUserName(username));
		User user = null;
		Academic academic = null;
		if(optional.isPresent()) {
			user = optional.get();
			long id = user.getId();
			Optional<Academic> opt = academicRepository.findById(id);
			if(opt.isPresent()) {
				academic = opt.get();
				return academic;
			}
		}
		return null;
	}
	@Override
	public List<Course> getAllCourse() {
		return courseRepository.findAll();
	}
	
	
}

