package com.way.project1.service;


import java.util.List;

import com.way.project1.dto.FeeDetailsEnteringRequest;
import com.way.project1.dto.FeeDetailsEnteringResponse;
import com.way.project1.dto.ShowUserDetails;
import com.way.project1.entity.Academic;
import com.way.project1.entity.Course;
import com.way.project1.entity.User;

public interface StudentAcademicService{
	public ShowUserDetails getStudentByUserName(String username);

	public User updateStudentDetails(String username, User user);

	public Academic updateStudentAcademicDetails(String username);

	public Course getCourseByCourseName(String courseName);

	public List<Course> getAllCourse();

	public FeeDetailsEnteringResponse enterFeeDetails(FeeDetailsEnteringRequest FDERe1, String username);
	
	
}
