package com.way.project1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.way.project1.entity.CourseRegistration;

public interface CourseRegistrationRepository extends JpaRepository<CourseRegistration, Long> {

	public List<CourseRegistration> findAllByCourseId(long courseId);

	public List<CourseRegistration> findAllByUserId(Long userId);
	
}
