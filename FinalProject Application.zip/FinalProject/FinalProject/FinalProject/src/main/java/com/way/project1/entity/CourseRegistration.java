package com.way.project1.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Course_registration")
public class CourseRegistration {
	@Id
	@GeneratedValue
	private long id;
	private long courseId;
	private long userId;
	private int feesPaid;
	private Date feesPaidDate;
	private int balanceFees;
}
