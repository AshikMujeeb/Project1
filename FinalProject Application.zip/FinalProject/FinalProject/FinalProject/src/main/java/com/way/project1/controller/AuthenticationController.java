package com.way.project1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.way.project1.dto.AuthenticationRequest;
import com.way.project1.dto.AuthenticationResponse;
import com.way.project1.util.JwtUtil;

@RestController
public class AuthenticationController {
	
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	
	@Autowired
	private JwtUtil jwtUtil;
	
	
	@PostMapping("/authenticate")
	public ResponseEntity<AuthenticationResponse> generateTokenAdmin(
			@RequestBody AuthenticationRequest authenticationRequest) {
		authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(),
				authenticationRequest.getPassword()));
		String jwt = jwtUtil.generateToken(authenticationRequest.getUsername());
		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	}
	
	
}
