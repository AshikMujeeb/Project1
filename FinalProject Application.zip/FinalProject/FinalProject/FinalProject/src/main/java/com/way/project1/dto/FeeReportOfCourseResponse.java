package com.way.project1.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FeeReportOfCourseResponse {
	private double totalFeesCollected;
	private double totalFeesToBeCollected;
}
