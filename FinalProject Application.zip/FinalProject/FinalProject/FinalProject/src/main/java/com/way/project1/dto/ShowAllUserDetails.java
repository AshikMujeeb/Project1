package com.way.project1.dto;

import java.util.List;

import com.way.project1.entity.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShowAllUserDetails {
	private List<User> list;
}
