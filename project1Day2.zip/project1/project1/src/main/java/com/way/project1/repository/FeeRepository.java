package com.way.project1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.way.project1.entity.Fee;

public interface FeeRepository extends JpaRepository<Fee, Long> {

}
