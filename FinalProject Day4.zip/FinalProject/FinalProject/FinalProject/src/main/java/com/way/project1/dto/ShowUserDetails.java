package com.way.project1.dto;

import com.way.project1.entity.Academic;
import com.way.project1.entity.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShowUserDetails {
	private User user;
	private Academic academic;
}
