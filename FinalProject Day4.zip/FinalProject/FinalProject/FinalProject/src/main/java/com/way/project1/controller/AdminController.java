package com.way.project1.controller;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.way.project1.dto.CourseDeletionConfirmation;
import com.way.project1.dto.CourseDetailsEnteringRequest;
import com.way.project1.dto.CourseDetailsEnteringResponse;
import com.way.project1.dto.DetailsEnteringConfirmation;
import com.way.project1.dto.DetailsEnteringRequest;
import com.way.project1.dto.FeeReportOfCourseResponse;
import com.way.project1.dto.ShowUserDetailsByCourse;
import com.way.project1.entity.Course;
import com.way.project1.service.AdminServiceImpl;

@RestController
public class AdminController {
	@Autowired
	public AdminServiceImpl adminServiceImpl;
	
	@PostMapping("/AdminstudentDetailsEntering")
	public DetailsEnteringConfirmation EnterUserDeatils(@RequestBody DetailsEnteringRequest detailsEnteringRequest) {
		return adminServiceImpl.EnterDetails(detailsEnteringRequest);
	}


	@PostMapping("/AdminCourseDetailsEntering")
	public CourseDetailsEnteringResponse CourseEnteringDetails(
			@RequestBody CourseDetailsEnteringRequest courseDetailsEnteringRequest) {
		return adminServiceImpl.courseEnteringDetails(courseDetailsEnteringRequest);
	}

	@PutMapping("/CourseDetailsUpdate/{coursename}")
	public Course UpdateDetails(@PathVariable(name = "coursename") String coursename,
			@RequestBody CourseDetailsEnteringRequest detailsEnteringRequest) {
		return adminServiceImpl.updateCourseDetails(coursename, detailsEnteringRequest.getCourse());
	}

	@DeleteMapping("/CourseDetailsDeletion/{coursename}")
	public CourseDeletionConfirmation CourseDetailsDeletion(@PathVariable("coursename") String courseName) {
		return adminServiceImpl.courseDetailsDeletion(courseName);
	}
	@GetMapping("/getDetailsbasedOnDateOfCourseRegistration")
	public LinkedHashMap<String,Date> GetDetailsBasedOnDate(){
		return adminServiceImpl.getCourseRegistrationDetails();
	}
	@GetMapping("/GetStudentWhoNotPaidFull")
	public LinkedHashMap<String,String> GetStudentWhoNotPaidFull(){
		return adminServiceImpl.getStudentWhoNotPaidFull();	}
	@GetMapping("/GetStudentWhoPaidFull")
	public List<String> GetStudentWhoPaidFull(){
		return adminServiceImpl.getStudentWhoPaidFull();	}
	@GetMapping("/ShowUserDetailsWhoRegisteredCourse/{CourseName}")
	public ShowUserDetailsByCourse ShowUserDetailsWhoRegisteredCourse(@PathVariable("CourseName") String name) {
		return new ShowUserDetailsByCourse(adminServiceImpl.showUserDetailsWhoRegisteredCourse(name));
	}
	@GetMapping("/GetFeeReport")
	public FeeReportOfCourseResponse FeeReportOfCourseRegistered() {
		return adminServiceImpl.feeReportOfCourseRegistered();
	}
	@GetMapping("/getCourseRegisteredByTheStudent/{userName}")
	public List<Course> ShowCourseRegisteredByStudent(@PathVariable String userName) {
		return adminServiceImpl.showCourseRegisteredByStudent(userName);
	}
	
}
