package com.way.project1.service;


import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.way.project1.dto.FeeDetailsEnteringRequest;
import com.way.project1.dto.FeeDetailsEnteringResponse;
import com.way.project1.dto.ShowUserDetails;
import com.way.project1.entity.Academic;
import com.way.project1.entity.Course;
import com.way.project1.entity.CourseRegistration;
import com.way.project1.entity.User;
import com.way.project1.repository.AcademicRepository;
import com.way.project1.repository.CourseRegistrationRepository;
import com.way.project1.repository.CourseRepository;
import com.way.project1.repository.UserRepository;

@Service
public class StudentAcademicServiceImpl implements StudentAcademicService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private AcademicRepository academicRepository;
	@Autowired
	private CourseRepository courseRepository;
	@Autowired
	private CourseRegistrationRepository courseRegistrationRepository;

	@Override
	public User updateStudentDetails(String username, User user) {
		Optional<User> optional = Optional.ofNullable(userRepository.findByUserName(username));
		User user1 = new User();
		if (optional.isEmpty()) {
			return null;
		} else {
			user1 = optional.get();
			user1.setEmail(user.getEmail());
			user1.setPh_no(user.getPh_no());
			user1.setPassword(user.getPassword());
			return user1;
		}
	}
	@Override
	public Course updateCourseDetails(String courseName, Course course) {
		Optional<Course> optional = Optional.ofNullable(courseRepository.findByCourseName(courseName));
		Course course1 = new Course();
		if (optional.isEmpty()) {
			return null;
		} else {
			course1 = optional.get();
			course1.setCourseName(course.getCourseName());
			course1.setDescription(course.getDescription());
			course1.setFees(course.getFees());
			return course1;
		}
	}

	@Override
	public Academic updateStudentAcademicDetails(String username) {
		Optional<User> optional = Optional.ofNullable(userRepository.findByUserName(username));
		User user = null;
		Long id = null;
		Academic academic = null;
		if (optional.isPresent()) {
			user = optional.get();
			id = user.getId();
			Optional<Academic> opt = academicRepository.findById(id);
			if (opt.isPresent()) {
				academic = opt.get();
				return academic;
			}
		}
		return null;
	}

	@Override
	public Course getCourseByCourseName(String courseName) {
		Optional<Course> optional = Optional.ofNullable(courseRepository.findByCourseName(courseName));
		Course c1 = null;
		if (optional.isPresent()) {
			c1 = optional.get();
			return c1;
		} else {
			return null;
		}
	}
	@Override
	public ShowUserDetails getStudentByUserName(String username) {
		User user = new User();
		Academic academic = new Academic();
		Optional<User> optional = Optional.ofNullable(userRepository.findByUserName(username));
		user = optional.get();
		if (optional.isPresent()) {
			user = optional.get();
			Optional<Academic> opt = academicRepository.findById(user.getId());
			if(opt.isPresent()) {
				academic = opt.get();
			}
		}return new ShowUserDetails(user,academic);
	}

	@Override
	public List<Course> getAllCourse() {
		return courseRepository.findAll();
	}
	@Override
	public FeeDetailsEnteringResponse enterFeeDetails(FeeDetailsEnteringRequest feeDetailsEnteringRequest,
			String username) {
		CourseRegistration fee = new CourseRegistration();
		Optional<User> optional = Optional.ofNullable(userRepository.findByUserName(username));
		if (optional.isPresent()) {
			User user = optional.get();
			fee.setUserId(user.getId());
		}
		Optional<Course> opt = Optional.ofNullable(courseRepository.findByCourseName(feeDetailsEnteringRequest.getCoursename()));
		if (opt.isPresent()) {
			Course course = opt.get();
			fee.setCourseId(course.getId());
		}
		fee.setFeesPaid(feeDetailsEnteringRequest.getFeesPaid());
		fee.setFeesPaidDate(feeDetailsEnteringRequest.getFeesPaidDate());
		courseRegistrationRepository.save(fee);
		return new FeeDetailsEnteringResponse("Details saved successfully");
	}
}
	
