package com.way.project1.service;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import com.way.project1.dto.CourseDeletionConfirmation;
import com.way.project1.dto.CourseDetailsEnteringRequest;
import com.way.project1.dto.CourseDetailsEnteringResponse;
import com.way.project1.dto.DetailsEnteringConfirmation;
import com.way.project1.dto.DetailsEnteringRequest;
import com.way.project1.dto.FeeReportOfCourseResponse;
import com.way.project1.entity.Academic;
import com.way.project1.entity.Course;
import com.way.project1.entity.User;

public interface AdminService{

	public DetailsEnteringConfirmation EnterDetails(DetailsEnteringRequest detailsEnteringRequest);
	
	public CourseDetailsEnteringResponse courseEnteringDetails(
			CourseDetailsEnteringRequest courseDetailsEnteringRequest);
	
	public CourseDeletionConfirmation courseDetailsDeletion(String courseName);
	
	public List<String> getStudentWhoPaidFull();
	
	public LinkedHashMap<String, String> getStudentWhoNotPaidFull();
	
	public LinkedHashMap<String, Date> getCourseRegistrationDetails();
	
	public Course updateCourseDetails(String courseName, Course course);
	
	public LinkedHashMap<User, Academic> showUserDetailsWhoRegisteredCourse(String Course);
	
	public List<Course> showCourseRegisteredByStudent(String student);
	
	public FeeReportOfCourseResponse feeReportOfCourseRegistered();
	
}
