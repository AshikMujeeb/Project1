package com.way.project1.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.way.project1.dto.CourseDeletionConfirmation;
import com.way.project1.dto.CourseDetailsEnteringRequest;
import com.way.project1.dto.CourseDetailsEnteringResponse;
import com.way.project1.dto.DetailsEnteringConfirmation;
import com.way.project1.dto.DetailsEnteringRequest;
import com.way.project1.dto.FeeReportOfCourseResponse;
import com.way.project1.entity.Academic;
import com.way.project1.entity.Course;
import com.way.project1.entity.CourseRegistration;
import com.way.project1.entity.User;
import com.way.project1.repository.AcademicRepository;
import com.way.project1.repository.CourseRegistrationRepository;
import com.way.project1.repository.CourseRepository;
import com.way.project1.repository.UserRepository;



@Service
public class AdminServiceImpl implements AdminService{
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private AcademicRepository academicRepository;
	@Autowired
	private CourseRegistrationRepository courseRegistrationRepository;
	@Autowired
	private CourseRepository courseRepository;
	@Transactional
	@Override
	public DetailsEnteringConfirmation EnterDetails(DetailsEnteringRequest detailsEnteringRequest) {
		User user = detailsEnteringRequest.getUser();
		Date date = new Date(System.currentTimeMillis());
		
		if ((date.getTime() - user.getDob().getTime()) / (1000l * 60 * 60 * 24 * 365) > 18 & getNumbervalidate(user.getPh_no())) {
			userRepository.save(user);
			Academic academic = detailsEnteringRequest.getAcademic();
			academic.setId(user.getId());
			academicRepository.save(academic);
			return new DetailsEnteringConfirmation(user.getFirst_name(), "Student successfully added!");
		} else
			return new DetailsEnteringConfirmation(user.getFirst_name()," : Age is below the 18, therefore you cant apply");	
		}
	public boolean getNumbervalidate(long number) {
		long input = number;
		int i = 0;
		while(i>0){
			input=input%10;
			i+=1;
		}
		if(i==10) {
			return true;
		}else {
			return false;
		}
	}
	@Override
	public CourseDetailsEnteringResponse courseEnteringDetails(
			CourseDetailsEnteringRequest courseDetailsEnteringRequest) {

		Course course = courseDetailsEnteringRequest.getCourse();
		courseRepository.save(course);
		return new CourseDetailsEnteringResponse(course.getCourseName(), "Successful");
	
	}
	@Override
	public CourseDeletionConfirmation courseDetailsDeletion(String courseName) {

		Optional<Course> optional = Optional.ofNullable(courseRepository.findByCourseName(courseName));
		Course course = null;
		if (optional.isPresent()) {
			course = optional.get();
		}
		courseRepository.delete(course);
		return new CourseDeletionConfirmation("Deletion Successful!");
	
	}
	@Override
	public List<String> getStudentWhoPaidFull() {

		List<CourseRegistration> list = courseRegistrationRepository.findAll();
		List<String> lhm = new LinkedList<>();
		for(CourseRegistration cr:list) {
			if(cr.getBalanceFees()==0) {
				Optional<User> optional = userRepository.findById(cr.getUserId());
				if(optional.isPresent()) {
					User user = optional.get();
					lhm.add(user.getUserName());
				}
			}
		}
		return lhm;
	
	}
	@Override
	public LinkedHashMap<String, String> getStudentWhoNotPaidFull() {

		List<CourseRegistration> list = courseRegistrationRepository.findAll();
		LinkedHashMap<String,String> lhm = new LinkedHashMap<String,String>();
		for(CourseRegistration cr:list) {
			if(cr.getBalanceFees()!=0) {
				Optional<User> optional = userRepository.findById(cr.getUserId());
				if(optional.isPresent()) {
					User user = optional.get();
					lhm.put(user.getUserName(),"Amount To Be Paid:- "+cr.getBalanceFees());
				}
			}
		}
		return lhm;
	
	
	}
	@Override
	public LinkedHashMap<String, Date> getCourseRegistrationDetails() {

		 List<CourseRegistration> acad = courseRegistrationRepository.findAll(Sort.by(Sort.Direction.ASC,"feesPaidDate"));
		 LinkedHashMap<String,Date> map= new LinkedHashMap<String,Date>();
		 for(CourseRegistration o:acad) {
			 
			 Optional<User> optional =userRepository.findById(o.getUserId());
			 if(optional.isPresent()) {
				 User user = optional.get();
				 Date date = o.getFeesPaidDate();
				 String username = user.getUserName();
				 map.put(username, date);
				 
			 }
		 }return map;
	
	}
	@Override
	public Course updateCourseDetails(String courseName, Course course) {
		Optional<Course> optional = Optional.ofNullable(courseRepository.findByCourseName(courseName));
		Course course1 = null;
		if (optional.isEmpty()) {
			return null;
		} else {
			course1 = optional.get();
			course1.setCourseName(course.getCourseName());
			course1.setDescription(course.getDescription());
			course1.setFees(course.getFees());
			return course1;
		}
	}
	@Override
	public FeeReportOfCourseResponse feeReportOfCourseRegistered() {
		double totalFeesCollected = 0;
		double totalFeesToBeCollected = 0;
		List<CourseRegistration> lcr = courseRegistrationRepository.findAll();
		for(CourseRegistration cr : lcr) {
			totalFeesCollected += cr.getFeesPaid();
			totalFeesToBeCollected += cr.getBalanceFees();
		}
		return new FeeReportOfCourseResponse(totalFeesCollected,totalFeesToBeCollected);
	}
	
	@Override
	public LinkedHashMap<User, Academic>  showUserDetailsWhoRegisteredCourse(String courseName) {
		long courseId = 0;
		Course course = new Course();
		Optional<Course> opt = Optional.ofNullable(courseRepository.findByCourseName(courseName));
		if(opt.isPresent()) {
			course = opt.get();
			courseId = course.getId();
		}
		LinkedHashMap<User,Academic> student = new LinkedHashMap<User,Academic>();
		List<CourseRegistration> ll = courseRegistrationRepository.findAllByCourseId(courseId);
		for(CourseRegistration o : ll) {
			Optional<User> opt1 = userRepository.findById(o.getUserId());
			Optional<Academic> opt2 = academicRepository.findById(o.getUserId());
			User user =  new User();
			Academic academic = new Academic();
			if(opt1.isPresent() & opt2.isPresent()){
				user = opt1.get();
				academic = opt2.get();
			}
			student.put(user,academic);
		}
		return student;
	}
	
	@Override
	public List<Course> showCourseRegisteredByStudent(String student) {
		long userId = 0;
		User user = new User();
		Optional<User> opt = Optional.ofNullable(userRepository.findByUserName(student));
		if(opt.isPresent()) {
			user = opt.get();
			userId = user.getId();
		}
		List<Course> courseList = new ArrayList<Course>();
		List<CourseRegistration> ll = courseRegistrationRepository.findAllByUserId(userId);

		System.out.println(ll.size());
		Course course =  new Course();
		for(CourseRegistration o : ll) {
			Optional<Course> opt1 = courseRepository.findById(o.getCourseId());
			System.out.println(opt1.isPresent());
			if(opt1.isPresent()){
				course = opt1.get();
				courseList.add(course);
			}
		}
		return courseList;
	}
}
 