package com.way.project1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.way.project1.dto.DetailsEnteringRequest;
import com.way.project1.dto.FeeDetailsEnteringRequest;
import com.way.project1.dto.FeeDetailsEnteringResponse;
import com.way.project1.entity.Academic;
import com.way.project1.entity.Course;
import com.way.project1.entity.User;
import com.way.project1.service.StudentAcademicServiceImpl;

@RestController
public class StudentController {

	@Autowired
	public StudentAcademicServiceImpl studentAcademicServiceImpl;
	
	@PutMapping("/StudentUserUpdateDetails/{username}")
	public User UpdateDetails(@PathVariable(name = "username") String username,
			@RequestBody DetailsEnteringRequest detailsEnteringRequest) {
		return studentAcademicServiceImpl.updateStudentDetails(username, detailsEnteringRequest.getUser());
	}

	@PutMapping("/StudentAcademicDetailsUpdate/{username}")
	public Academic updateAcademicDetails(@PathVariable(name = "username") String username) {
		return studentAcademicServiceImpl.updateStudentAcademicDetails(username);
	}
	@PostMapping("/EnteringFeeDetails/{username}")
	public FeeDetailsEnteringResponse AddFeeDetails(@RequestBody FeeDetailsEnteringRequest feeDetailsEnteringRequest,
			@PathVariable("username") String username) {
		return studentAcademicServiceImpl.enterFeeDetails(feeDetailsEnteringRequest, username);
	}
	@GetMapping("/getCourseDetails/{coursename}")
	public Course GetCourseDetails(@PathVariable(name = "coursename") String courseName) {
		return studentAcademicServiceImpl.getCourseByCourseName(courseName);
	}

	@GetMapping("/getAllCourseDetails")
	public List<Course> GetAllCourseDetails() {
		return studentAcademicServiceImpl.getAllCourse();
	}

}
