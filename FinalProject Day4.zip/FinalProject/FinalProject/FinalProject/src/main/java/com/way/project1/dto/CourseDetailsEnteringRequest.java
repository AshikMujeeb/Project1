package com.way.project1.dto;

import com.way.project1.entity.Course;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourseDetailsEnteringRequest {
	private Course course;
}
