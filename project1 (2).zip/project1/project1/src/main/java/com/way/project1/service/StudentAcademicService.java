package com.way.project1.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.way.project1.dto.DetailsEnteringConfirmation;
import com.way.project1.dto.DetailsEnteringRequest;
import com.way.project1.dto.StudentDetailsConfirmation;
import com.way.project1.entity.Academic;
import com.way.project1.entity.User;

public interface StudentAcademicService extends UserDetailsService{
	public DetailsEnteringConfirmation EnterDetails(DetailsEnteringRequest detailsEnteringRequest );
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException;
	public User getStudentByUseName(String username);
	public User updateStudentDetails(String username,User user);
	public Academic updateStudentAcademicDetails(long id,Academic academic);
}
