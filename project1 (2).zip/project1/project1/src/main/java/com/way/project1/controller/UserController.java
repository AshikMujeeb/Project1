package com.way.project1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.way.project1.dto.AuthenticationRequest;
import com.way.project1.dto.AuthenticationResponse;
import com.way.project1.dto.DetailsEnteringConfirmation;
import com.way.project1.dto.DetailsEnteringRequest;
import com.way.project1.entity.Academic;
import com.way.project1.entity.User;
import com.way.project1.service.StudentAcademicServiceImpl;
import com.way.project1.util.JwtUtil;

@RestController
public class UserController {
	@Autowired
	public StudentAcademicServiceImpl studentAcademicServiceImpl;
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private JwtUtil jwtUtil;
	
	@PostMapping("/authenticate")
	public ResponseEntity<AuthenticationResponse> generateToken(@RequestBody AuthenticationRequest authenticationRequest){
		authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword()));
		String jwt = jwtUtil.generateToken(authenticationRequest.getUsername());
		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	}
	@PostMapping("/AdminstudentDetailsEntering")
	public DetailsEnteringConfirmation EnterUserDeatils(@RequestBody DetailsEnteringRequest detailsEnteringRequest){
		return studentAcademicServiceImpl.EnterDetails( detailsEnteringRequest);
	}
	@PostMapping("/getStudentDetails/{username}")
	public User getStudentDetails(@PathVariable("username") String username) {
		return studentAcademicServiceImpl.getStudentByUseName(username);
	}
	@PostMapping("/StudentUserUpdateDetails/{username}")
	public User UpdateDetails(@PathVariable String username, @RequestBody DetailsEnteringRequest detailsEnteringRequest) {
		return studentAcademicServiceImpl.updateStudentDetails(username, detailsEnteringRequest.getUser());
	}
	@PostMapping("/StudentAcademicDetailsUpdate/{id}")
	public Academic updateAcademicDetails(long id,DetailsEnteringRequest detailsEnteringRequest) {
		return studentAcademicServiceImpl.updateStudentAcademicDetails(id, detailsEnteringRequest.getAcademic());
	}
}
