package com.way.project1.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "academic_details")
public class Academic {
	@Id
	private long id;
	private String qualifiaction;
	private String college;
	private String university;
	private int pass_out_year;
}
