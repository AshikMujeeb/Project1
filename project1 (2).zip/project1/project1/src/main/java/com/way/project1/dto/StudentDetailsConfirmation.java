package com.way.project1.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.way.project1.entity.Academic;
import com.way.project1.entity.User;

public class StudentDetailsConfirmation {
	private String firstName;
	private String lastName;
	private String email;
	private Long phone;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	private Date dob;
	private Academic academic;
}
