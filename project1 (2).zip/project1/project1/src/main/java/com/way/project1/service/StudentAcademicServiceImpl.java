package com.way.project1.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.way.project1.dto.DetailsEnteringConfirmation;
import com.way.project1.dto.DetailsEnteringRequest;
import com.way.project1.dto.StudentDetailsConfirmation;
import com.way.project1.entity.Academic;
import com.way.project1.entity.User;
import com.way.project1.repository.AcademicRepository;
import com.way.project1.repository.UserRepository;


@Service
public class StudentAcademicServiceImpl implements StudentAcademicService{
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private AcademicRepository academicRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByUserName(username);
		return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), new ArrayList<>());
	}
	@Override
	public DetailsEnteringConfirmation EnterDetails(DetailsEnteringRequest detailsEnteringRequest ) {
		User user = detailsEnteringRequest.getUser();
		userRepository.save(user);
		Academic academic = detailsEnteringRequest.getAcademic();
		academic.setId(user.getId());
		academicRepository.save(academic);
		return new DetailsEnteringConfirmation(user.getFirst_name(),"Student successfully added!");
	}
	@Override
	public User getStudentByUseName(String username) {
		Optional<User> optional = Optional.ofNullable(userRepository.findByUserName(username));
		if(optional.isEmpty() )
			return null;
		else
			return optional.get();
	}
	@Override
	public User updateStudentDetails(String username, User user) {
		Optional<User> optional = Optional.ofNullable(userRepository.findByUserName(username));
		User user1 = null;
		if(optional.isEmpty()) {
			return null;
		}else {
			user1 = optional.get();
			user1.setEmail(user.getEmail());
			user1.setPh_no(user.getPh_no());
			user1.setPassword(user.getPassword());
			return user1;
		}
	}
	
	@Override
	public Academic updateStudentAcademicDetails(long id, Academic academic) {

		Optional<Academic> optional = academicRepository.findById(id);
		Academic acad1 = null;
		if(optional.isEmpty()) {
			return null;
		}else {
			acad1 = optional.get();
			acad1.setCollege(academic.getCollege());
			acad1.setPass_out_year(academic.getPass_out_year());
			acad1.setQualifiaction(academic.getQualifiaction());
			return acad1;
		}
	
	}
}

